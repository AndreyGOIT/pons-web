// src/enums/CourseType.ts
export enum CourseType {
    KN = 'KN - kuntonyrkkeily',
    NUORISO = 'Nuoriso ryhmä',
    KILPA = 'Kilparyhmä',
  }